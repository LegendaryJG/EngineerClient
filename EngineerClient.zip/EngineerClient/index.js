

//EngineerClient
import "./features/EngineerSplits";
import "./features/EngineerSubSplits";
import "./features/EngineerPurplePadTimer";
import "./features/EngineerClient";
import "./features/EngineerMaskTImer";
import "./features/EngineerChatCleaner";
import "./features/EngineerSheepHider";
// import "./features/EngineerAutokick"
import "./features/Terminals/EngineerCoreMessage";
import "./features/Terminals/EngineerEEAlert";
import "./features/Terminals/EngineerEEMove";
import "./features/Terminals/EngineerTermInfo";
// import "./features/Terminals/solver/EngineerTermSolver";